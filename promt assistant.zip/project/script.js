// ===============================
// PromptGenius AI Assistant
// script.js
// ===============================

// Generate AI Response
function generateResponse() {

    const functionType = document.getElementById("function").value;
    const prompt = document.getElementById("prompt").value.trim();
    const responseBox = document.getElementById("response");

    if (prompt === "") {
        alert("Please enter a prompt.");
        return;
    }

    let response = "";

    // -----------------------------
    // Question Answering
    // -----------------------------
    if (functionType === "Answer Questions") {

        const text = prompt.toLowerCase();

        if (text.includes("ai")) {
            response = "Artificial Intelligence (AI) is the simulation of human intelligence by machines. AI enables computers to learn, reason, solve problems, and make decisions.";
        }

        else if (text.includes("computer")) {
            response = "A computer is an electronic device that accepts input, processes data, stores information, and produces output.";
        }

        else if (text.includes("html")) {
            response = "HTML stands for HyperText Markup Language. It is used to create the structure of web pages.";
        }

        else if (text.includes("css")) {
            response = "CSS stands for Cascading Style Sheets. It is used to style and design web pages.";
        }

        else if (text.includes("javascript")) {
            response = "JavaScript is a programming language that adds interactivity and dynamic behavior to websites.";
        }

        else {

            const answers = [

                "This is an interesting question. Try providing more details.",

                "Based on your prompt, more information is needed to give an accurate answer.",

                "I understand your question, but this offline assistant has limited knowledge."

            ];

            response = randomItem(answers);
        }

    }

    // -----------------------------
    // Summarizer
    // -----------------------------
    else if (functionType === "Summarize Text") {

        let sentences = prompt.split(".");

        if (sentences.length > 2) {

            response =
                "Summary:\n\n" +
                sentences.slice(0, 2).join(".") + ".";

        } else {

            response =
                "The provided text is already short and does not require summarization.";

        }

    }

    // -----------------------------
    // Creative Generator
    // -----------------------------
    else {

        const stories = [

`Once upon a time, a young engineer created an AI assistant that helped thousands of students complete their projects successfully.`,

`A small robot dreamed of becoming a scientist. With determination and learning, it finally built a machine that changed the world.`,

`A college student developed an innovative business idea using prompt engineering and later became a successful entrepreneur.`,

`In the year 2050, humans and AI worked together to solve environmental problems and improve education.`

        ];

        response = randomItem(stories);

    }

    responseBox.innerText = response;

    saveHistory(functionType, prompt);

}

// -----------------------------
// Copy Response
// -----------------------------
function copyResponse() {

    const text = document.getElementById("response").innerText;

    navigator.clipboard.writeText(text);

    alert("Response copied successfully!");

}

// -----------------------------
// Download Response
// -----------------------------
function downloadResponse() {

    const text = document.getElementById("response").innerText;

    const blob = new Blob([text], { type: "text/plain" });

    const link = document.createElement("a");

    link.href = URL.createObjectURL(blob);

    link.download = "AI_Response.txt";

    link.click();

}

// -----------------------------
// Feedback
// -----------------------------
function feedback(value){

    alert("Thank you for your feedback: " + value);

}

// -----------------------------
// Save Prompt History
// -----------------------------
function saveHistory(type, prompt){

    let history =
        JSON.parse(localStorage.getItem("promptHistory")) || [];

    history.push({

        function:type,

        prompt:prompt,

        date:new Date().toLocaleString()

    });

    localStorage.setItem(

        "promptHistory",

        JSON.stringify(history)

    );

}

// -----------------------------
// Random Item
// -----------------------------
function randomItem(array){

    return array[Math.floor(Math.random()*array.length)];

}